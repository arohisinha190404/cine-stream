const API_BASE = 'https://api.themoviedb.org/3';
const TOKEN = import.meta.env.VITE_TMDB_TOKEN;
export const IMAGE_BASE = 'https://image.tmdb.org/t/p/w500';

async function request(path, signal) {
  if (!TOKEN || TOKEN === 'replace_with_your_tmdb_read_access_token') {
    throw new Error('TMDB token missing. Copy .env.example to .env and add your TMDB Read Access Token.');
  }

  const response = await fetch(`${API_BASE}${path}`, {
    signal,
    headers: {
      accept: 'application/json',
      Authorization: `Bearer ${TOKEN}`,
    },
  });

  if (!response.ok) {
    if (response.status === 401) throw new Error('TMDB rejected the token. Check VITE_TMDB_TOKEN in your .env file.');
    if (response.status === 429) throw new Error('TMDB rate limit reached. Please wait a moment and try again.');
    throw new Error(`TMDB request failed (${response.status}). Please try again.`);
  }
  return response.json();
}

export function getPopularMovies(page = 1, signal) {
  return request(`/movie/popular?language=en-US&page=${page}`, signal);
}

export function searchMovies(query, page = 1, signal) {
  return request(`/search/movie?query=${encodeURIComponent(query)}&include_adult=false&language=en-US&page=${page}`, signal);
}
