import { Heart, Star } from 'lucide-react';
import { IMAGE_BASE } from '../api/tmdb.js';

export default function MovieCard({ movie, isFavorite, onToggleFavorite }) {
  const year = movie.release_date ? movie.release_date.slice(0, 4) : 'Year unknown';
  return (
    <article className="movie-card">
      <div className="poster-wrap">
        {movie.poster_path ? (
          <img
            className="poster"
            src={`${IMAGE_BASE}${movie.poster_path}`}
            alt={`${movie.title || movie.name || 'Movie'} poster`}
            loading="lazy"
          />
        ) : (
          <div className="poster-placeholder" role="img" aria-label="Poster unavailable">
            <span>POSTER</span><small>NOT AVAILABLE</small>
          </div>
        )}
        <button
          className={`favorite-button ${isFavorite ? 'active' : ''}`}
          type="button"
          onClick={() => onToggleFavorite(movie)}
          aria-label={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
          title={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
        >
          <Heart size={19} fill={isFavorite ? 'currentColor' : 'none'} />
        </button>
        <div className="rating"><Star size={14} fill="currentColor" /> {Number(movie.vote_average || 0).toFixed(1)}</div>
      </div>
      <div className="movie-info">
        <h3 title={movie.title}>{movie.title || movie.name || 'Untitled movie'}</h3>
        <p>{year}</p>
      </div>
    </article>
  );
}
